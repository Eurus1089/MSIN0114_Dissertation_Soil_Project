# app.py
# ----------------------------------------------------------
# Soil Nutrient Balance Predictor (single-record UI)
# - English UI
# - Local run only
# - Single prediction (no batch)
# - Location -> Crop cascading select
# - Environmental features: upload one-row CSV or fill manually
# - 95% CI shown only if the loaded pipeline exposes uncertainty
# ----------------------------------------------------------

import io
import cloudpickle
import pickle
import joblib
import numpy as np
import pandas as pd
import streamlit as st

# -----------------------------
# Custom classes for unpickling
# -----------------------------
class DiffModel:
    def __init__(self, in_model, out_model):
        self.in_model = in_model
        self.out_model = out_model
    def predict(self, X):
        return self.in_model.predict(X) - self.out_model.predict(X)

class EnsembleModel:
    def __init__(self, models, weights):
        self.models = models          # dict-like: name -> model
        self.weights = weights        # dict-like: name -> weight
    def predict(self, X):
        # Weighted sum over sub-models' predictions
        return sum(self.weights[n] * m.predict(X) for n, m in self.models.items())

class RawEnsemble:
    def __init__(self, pipelines, weights=None):
        self.pipelines = pipelines    # list-like of sklearn pipelines/estimators
        self.pipes = pipelines        # some pickles may refer to .pipes
        self.weights = weights or [1/len(pipelines)] * len(pipelines)
    def predict(self, X):
        pipes = getattr(self, "pipelines", None) or getattr(self, "pipes", [])
        preds = np.vstack([p.predict(X) for p in pipes]).T  # shape (n_samples, n_models)
        return preds.dot(self.weights)                      # weighted average

# -----------------------------
# Streamlit config
# -----------------------------
st.set_page_config(page_title="Soil Nutrient Balance Predictor", layout="wide")

MODEL_FILES = {
    "N_bal": "N_bal_diff_model.pkl",
    "P_bal": "P_bal_diff_model.pkl",
    "K_bal": "K_bal_direct_model.pkl",
    "S_bal": "S_bal_direct_model.pkl",
}

LOCATIONS = ["Bogura", "Cumilla", "Muktagacha"]
CROPS_BY_LOCATION = {
    "Bogura": ["Potato", "Boro", "T. Aus", "T. Aman"],
    "Cumilla": ["Boro", "T. Aus", "T. Aman"],
    "Muktagacha": ["Maize", "T. Aman"],
}
RESIDUE_OPTS = ["CR", "NR"]
TREATMENT_OPTS = ["CL", "FP", "RD", "125RD"]

ENV_FEATURES = [
    "C3_PAR_active_days_pct", "C4_PAR_active_days_pct", "calm_days_pct",
    "gdd_mean_daily", "gdd_total", "gwet_gradient_std", "gwet_prof_5p",
    "gwet_prof_mean", "gwet_prof_std", "gwet_root_5p", "gwet_root_95p",
    "gwet_top_5p", "gwet_top_median", "gwet_top_std", "heavy_rain_days_pct",
    "high_humidity_pct", "N_NE_pct", "N_NW_pct", "PAR_fraction_median",
    "rain_intensity_index", "rainfall_mean", "rainy_days_pct", "rh_max_std",
    "rh_min_std", "rh_range_mean", "S_SE_pct", "temp_max_above_30_pct",
    "temp_max_95p", "temp_max_mean", "temp_max_median", "temp_max_std",
    "temp_min_below_10_pct", "temp_min_below_5_pct", "temp_min_median",
    "temp_min_std", "temp_range_above_10_pct", "temp_range_above_15_pct",
    "temp_range_median", "thi_5p", "thi_95p", "thi_mean", "thi_moderate_pct",
    "UVA_UVB_ratio_std", "UVB_div_gwet_top_std", "UVB_mean", "UVB_std",
    "UVB_total", "UV_idx_mean", "vpd_lower_mean", "vpd_middle_mean",
    "vpd_stressed_pct", "W_NW_pct", "wind_speed_mean"
]

# -----------------------------
# Helpers
# -----------------------------
@st.cache_resource
def load_model(path: str):
    """
    Robust loader:
      1) try joblib.load
      2) try cloudpickle.load
      3) fallback to pickle.load
    Custom classes are already defined above, so pickle can resolve them.
    """
    if joblib is not None:
        try:
            return joblib.load(path)
        except Exception:
            pass
    if cloudpickle is not None:
        try:
            with open(path, "rb") as f:
                return cloudpickle.load(f)
        except Exception:
            pass
    with open(path, "rb") as f:
        return pickle.load(f)

def try_predict_with_interval(model, X: pd.DataFrame, alpha: float = 0.05):
    """
    Attempt to return (y_pred, lower, upper) as numpy arrays.
    If 95% CI is unsupported by the model, lower/upper = None.
    """
    # Basic point prediction (must work for a valid estimator)
    y_pred = model.predict(X)
    lower = upper = None

    # Try predict with return_std=True (GaussianProcessRegressor, some wrappers, etc.)
    try:
        y_mu, y_std = model.predict(X, return_std=True)
        z = 1.95996398454  # ~95% two-sided
        lower = y_mu - z * y_std
        upper = y_mu + z * y_std
        return np.asarray(y_mu).ravel(), np.asarray(lower).ravel(), np.asarray(upper).ravel()
    except Exception:
        pass

    # Try predict_interval if available (some libraries expose this)
    try:
        if hasattr(model, "predict_interval"):
            interval = model.predict_interval(X, alpha=alpha)
            if isinstance(interval, (list, tuple, np.ndarray)) and len(interval) == len(y_pred):
                # Assume [lower, upper] per row
                lower = np.array([row[0] for row in interval])
                upper = np.array([row[1] for row in interval])
            elif isinstance(interval, dict):
                lower = np.asarray(interval.get("lower") or interval.get("lwr"))
                upper = np.asarray(interval.get("upper") or interval.get("upr"))
            if lower is not None and upper is not None:
                return np.asarray(y_pred).ravel(), np.asarray(lower).ravel(), np.asarray(upper).ravel()
    except Exception:
        pass

    # No interval support
    return np.asarray(y_pred).ravel(), None, None

def parse_one_row_csv(file) -> dict:
    """
    Accept a CSV with header row and exactly one data row.
    Extra columns are ignored later; missing ones are left absent.
    """
    try:
        df = pd.read_csv(file)
    except Exception:
        # Fallback to auto-detect separator
        file.seek(0)
        df = pd.read_csv(file, sep=None, engine="python")

    if df.shape[0] == 0:
        raise ValueError("CSV contains no data rows.")
    if df.shape[0] > 1:
        st.warning("More than one row detected; only the first row will be used.")
    row = df.iloc[0]
    values = {str(col): row[col] for col in df.columns}
    return values

def to_float_or_nan(x):
    if x is None or (isinstance(x, str) and x.strip() == ""):
        return np.nan
    try:
        return float(x)
    except Exception:
        return np.nan

# -----------------------------
# UI - Layout
# -----------------------------
st.title("Soil Nutrient Balance Predictor")
st.write(
    "Single-record prediction for **N_bal / P_bal / K_bal / S_bal** using your pre-trained pipelines. "
    "Fill in the controls below, optionally add environmental features manually or via a one-row CSV, "
    "then click **Predict**."
)

# Target selection (this chooses which trained pipeline to load)
target = st.selectbox(
    "Target Nutrient Balance",
    options=["N_bal", "P_bal", "K_bal", "S_bal"],
    index=0,
    help="Choose which balance to predict; the app will load the corresponding trained pipeline."
)

# Categorical controls with cascading crop choices
with st.container():
    c1, c2, c3 = st.columns(3)
    with c1:
        location = st.selectbox("Location", LOCATIONS)
    with c2:
        crop = st.selectbox("Crop", CROPS_BY_LOCATION.get(location, []))
    with c3:
        residue = st.selectbox("Residue", RESIDUE_OPTS)

treatment = st.selectbox("Treatment", TREATMENT_OPTS)

st.divider()

# Environmental features: input mode
input_mode = st.radio(
    "Environmental features input",
    options=["Upload one-row CSV", "Fill manually"],
    index=0,
    help="CSV option expects a header row (feature names) and exactly one data row."
)

env_values = {}

if input_mode == "Upload one-row CSV":
    uploaded = st.file_uploader("Upload CSV (header + one data row)", type=["csv"])
    if uploaded is not None:
        try:
            parsed = parse_one_row_csv(uploaded)
            used = {k: parsed[k] for k in ENV_FEATURES if k in parsed}
            missing = [f for f in ENV_FEATURES if f not in used]
            env_values.update(used)
            st.success(f"Loaded {len(used)} features from CSV. Missing {len(missing)} will be left as NA.")
            with st.expander("Preview parsed values"):
                st.dataframe(pd.DataFrame([used]))
        except Exception as e:
            st.error(f"Failed to parse CSV: {e}")
else:
    st.caption("Enter any features you have; you can leave the rest blank.")
    cols = st.columns(3)
    for i, feat in enumerate(ENV_FEATURES):
        with cols[i % 3]:
            val = st.text_input(feat, value="", placeholder="e.g. 12.34")
            env_values[feat] = val

# -----------------------------
# Prediction
# -----------------------------
if st.button("Predict", type="primary"):
    # Build single-row record
    record = {
        "Location": location,
        "Crop": crop,
        "Residue": residue,
        "Treatment": treatment,
    }
    for feat in ENV_FEATURES:
        v = env_values.get(feat, None)
        record[feat] = to_float_or_nan(v)

    X = pd.DataFrame([record])

    # Load the chosen model
    model_path = MODEL_FILES[target]
    try:
        model = load_model(model_path)
    except Exception as e:
        st.error("Failed to load the model file.")
        st.exception(e)
        st.stop()

    # Optional feature check if estimator exposes names
    if hasattr(model, "feature_names_in_"):
        needed = list(model.feature_names_in_)
        missing_required = [c for c in needed if c not in X.columns]
        if missing_required:
            st.warning(
                f"The loaded model expects {len(needed)} features; "
                f"{len(missing_required)} missing from your input: "
                f"{missing_required[:10]}{' ...' if len(missing_required)>10 else ''}"
            )

    # Predict (try to show 95% CI if supported)
    try:
        y_pred, lower, upper = try_predict_with_interval(model, X)
        pred_val = float(y_pred[0])

        st.subheader("Prediction Result")
        if lower is not None and upper is not None:
            st.success(f"{target} = {pred_val:.4f}  (95% CI: {float(lower[0]):.4f} – {float(upper[0]):.4f})")
            st.caption("95% CI is shown only if the loaded model exposes uncertainty (e.g., returns std or intervals).")
        else:
            st.success(f"{target} = {pred_val:.4f}")
            st.info("This model does not expose a built-in uncertainty interface; showing point prediction only.")

        with st.expander("Show input features used"):
            st.dataframe(X.T.rename(columns={0: "value"}))
    except Exception as e:
        st.error("Prediction failed.")
        st.exception(e)
